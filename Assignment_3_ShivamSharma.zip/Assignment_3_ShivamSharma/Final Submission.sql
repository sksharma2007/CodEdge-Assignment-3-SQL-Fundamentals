Part 1: StudentDB

create database StudentDB;
use StudentDB;

CREATE TABLE Students (
    ->     Student_ID INT PRIMARY KEY,
    ->     Name VARCHAR(100),
    ->     Age INT,
    ->     Course VARCHAR(100),
    ->     Marks INT
    -> );

Part 2: Student Records

 INSERT INTO Students (Student_ID, Name, Age, Course, Marks)
    -> VALUES
    -> (101, 'Rahul Sharma', 20, 'Data Science', 85),
    -> (102, 'Priya Singh', 21, 'Computer Science', 92),
    -> (103, 'Aman Verma', 19, 'BCA', 78),
    -> (104, 'Sneha Patel', 22, 'Data Science', 88),
    -> (105, 'Arjun Mehta', 20, 'B.Tech', 81),
    -> (106, 'Riya Kapoor', 21, 'BCA', 74),
    -> (107, 'Karan Gupta', 22, 'Computer Science', 90),
    -> (108, 'Anjali Sharma', 20, 'Data Science', 86),
    -> (109, 'Rohit Jain', 19, 'B.Tech', 79),
    -> (110, 'Pooja Verma', 21, 'BCA', 83),
    -> (111, 'Vikas Singh', 22, 'Computer Science', 91),
    -> (112, 'Neha Agarwal', 20, 'Data Science', 87),
    -> (113, 'Aditya Mishra', 21, 'B.Tech', 76),
    -> (114, 'Simran Kaur', 19, 'BCA', 80),
    -> (115, 'Mohit Sharma', 22, 'Computer Science', 89),
    -> (116, 'Aisha Khan', 20, 'Data Science', 84),
    -> (117, 'Deepak Yadav', 21, 'B.Tech', 77),
    -> (118, 'Komal Jain', 19, 'BCA', 82),
    -> (119, 'Sahil Arora', 22, 'Computer Science', 93),
    -> (120, 'Nidhi Gupta', 20, 'Data Science', 88);

Part 3: Student Queries

     select * from Students;
     
     select Name, Marks from Students;

Part 4: EmployeeDB

    create database EmployeeDB;
    use EmployeeDB;

    CREATE TABLE Employees (
    ->     Employee_ID INT PRIMARY KEY,
    ->     Employee_Name VARCHAR(100),
    ->     Department VARCHAR(50),
    ->     Salary INT,
    ->     City VARCHAR(50)
    -> );

Part 5: Employee Records

     INSERT INTO Employees (Employee_ID, Employee_Name, Department, Salary, City)
    -> VALUES
    -> (101, 'Rahul Sharma', 'IT', 75000, 'Mumbai'),
    -> (102, 'Priya Singh', 'Finance', 82000, 'Delhi'),
    -> (103, 'Aman Verma', 'HR', 48000, 'Pune'),
    -> (104, 'Sneha Patel', 'Marketing', 56000, 'Ahmedabad'),
    -> (105, 'Arjun Mehta', 'IT', 68000, 'Delhi'),
    -> (106, 'Riya Kapoor', 'HR', 52000, 'Hyderabad'),
    -> (107, 'Karan Gupta', 'Finance', 91000, 'Mumbai'),
    -> (108, 'Anjali Sharma', 'IT', 62000, 'Bangalore'),
    -> (109, 'Rohit Jain', 'Sales', 47000, 'Delhi'),
    -> (110, 'Pooja Verma', 'Marketing', 59000, 'Pune'),
    -> (111, 'Vikas Singh', 'IT', 85000, 'Noida'),
    -> (112, 'Neha Agarwal', 'Finance', 78000, 'Delhi'),
    -> (113, 'Aditya Mishra', 'Sales', 51000, 'Lucknow'),
    -> (114, 'Simran Kaur', 'HR', 46000, 'Chandigarh'),
    -> (115, 'Mohit Sharma', 'IT', 73000, 'Mumbai'),
    -> (116, 'Aisha Khan', 'Marketing', 61000, 'Hyderabad'),
    -> (117, 'Deepak Yadav', 'Finance', 88000, 'Jaipur'),
    -> (118, 'Komal Jain', 'HR', 54000, 'Indore'),
    -> (119, 'Sahil Arora', 'IT', 69000, 'Delhi'),
    -> (120, 'Nidhi Gupta', 'Sales', 50000, 'Pune'),
    -> (121, 'Rakesh Kumar', 'Marketing', 58000, 'Delhi'),
    -> (122, 'Meera Joshi', 'Finance', 94000, 'Mumbai'),
    -> (123, 'Tarun Malhotra', 'IT', 81000, 'Bangalore'),
    -> (124, 'Isha Sharma', 'HR', 49000, 'Delhi'),
    -> (125, 'Yash Gupta', 'Sales', 53000, 'Noida'),
    -> (126, 'Kriti Singh', 'Marketing', 64000, 'Jaipur'),
    -> (127, 'Manish Verma', 'Finance', 86000, 'Pune'),
    -> (128, 'Sanya Kapoor', 'IT', 71000, 'Hyderabad'),
    -> (129, 'Abhishek Jain', 'Sales', 55000, 'Delhi'),
    -> (130, 'Riya Malhotra', 'HR', 70000, 'Mumbai');

Part 6: Intermediate Queries

        select * from Employees;
        
        select * from Employees WHERE Department='IT';
        
        SELECT * FROM Employees
     -> WHERE Salary>50000;

        select * from Employees where City='Delhi';
  
        select * from Employees order by Salary ASC;

        select * from Employees order by Salary DESC;

        select DISTINCT Department from Employees;

        select * from Employees order by Salary DESC LIMIT 10;

Part 7: Reporting Queries

        select count(*) AS total_employees from Employees;

        select Department, count(*) AS employee_count from Employees group by Department;

        select max(Salary) AS Highest_Salary from Employees;

        select min(Salary) AS Lowest_Salary from Employees;

        select * from Employees order by Salary DESC limit 5;
        
